#!/bin/sh
exec /opt/eclipse-ide-java/eclipse
